
<?php
session_start();
header("Location: ./views/Login.php");
?>